<?php
/**
 *Created by PhpStorm,
 *User: wangjingxu
 *Date:2017/11/30
 *Time:12:21
 */
namespace app\index\controller;
use app\index\model\Grade as GradeModel;
use think\Request;
use think\Session;
class Grade extends Base
{
    //班级列表界面
    public function gradeList()
    {
        $userRole = Session::get('user_info.role');
        $userName =Session::get('user_info.name');
        if ($userRole == 3) {
            $grade= GradeModel::all(['status'=>1]);
        } else {
            $grade = GradeModel::all();
        }
        /*$grade = GradeModel::all();*/

        $count = GradeModel::count();

        foreach ($grade as $value) {
            $data = [
                'id' => $value->id,
                'name' => $value->name,
                'length' => $value->length,
                'price' => $value->price,
                'type' => $value->type,
                'text' => $value->text,
                'require' => $value->require,
                'status' => $value->status,
                'create_time' => $value->create_time,
                'teacher' => isset($value->teacher->name)?$value->teacher->name:'<span style="color:red;">未分配</span>',
            ];

            $gradeList[] = $data;
        }

        $this->assign('gradeList', $gradeList);
        $this->assign('count', $count);
        $this->assign('title', '班级列表');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');

        return $this->fetch('grade_list');
    }

    //添加班级
    public function gradeAdd()
    {
        $this->assign('title', '添加论文');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');

        return $this->fetch('grade_add');
    }

    //执行添加班级功能
    public function doAdd(Request $request)
    {
        $data = $request->param();
        $status = 0;
        $message = '添加失败';

        $rule = [
             'name' => "require|max:100",
            'length' => "require|max:200",
            'price' => "require|max:500",
            'require' => "require|max:500",
            'type' => "require|max:100",
            'text' => "require|max:200"
        ];

        $result = $this->validate($data, $rule);

        if ($result === true) {
            $grade = GradeModel::create($data);
            if ($grade == true) {
                $status = 1;
                $message = '添加成功';
            }
        }

        return ['status'=>$status,'message'=>$message];
    }

    //课程状态切换
    public function setStatus(Request $request)
    {
        $grade_id = $request->param('id');
        $result = GradeModel::get($grade_id);
        if ($result->getData('status') == 1) {
            GradeModel::update(['status'=>0],['id'=>$grade_id]);
        } else {
            GradeModel::update(['status'=>1],['id'=>$grade_id]);
        }
    }

    //班级编辑界面
    public function gradeEdit(Request $request)
    {
        $grade_id = $request->param('id');
        $result = GradeModel::get($grade_id);
        $result->teacher = empty($result->teacher->name)?"未分配":$result->teacher->name;

        $this->assign('title', '编辑班级信息');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');
        $this->assign('grade_info',$result);

        return $this->fetch('grade_edit');
    }

    //班级编辑功能
    public function doEdit(Request $request)
    {
        $data = $request -> except('teacher');
        $condition = ['id'=>$data['id']];

        $result = GradeModel::update($data, $condition);

        if (true == $result) {
            return ['status'=>1, 'message'=>'更新成功'];
        } else {
            return ['status'=>0, 'message'=>'更新失败,请检查'];
        }
    }

    //删除班级
    public function deleteGrade(Request $request)
    {
        $grade_id = $request->param('id');
        GradeModel::update(['is_delete'=>1],['id'=>$grade_id]);
        GradeModel::destroy($grade_id);
    }

    //恢复删除
    public function unDelete()
    {
        GradeModel::update(['delete_time'=>null],['is_delete'=>1]);
    }
    public  function search()
    {
        $this->assign('title', '查找论文');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');
        $search = $_POST["username"];
        $grade = GradeModel::all(['name'=>$search]);
        $count = GradeModel::count();
        foreach ($grade as $value) {
            $data = [
                'id' => $value->id,
                'name' => $value->name,
                'length' => $value->length,
                'price' => $value->price,
                'type' => $value->type,
                'text' => $value->text,
                'require' => $value->require,
                'status' => $value->status,
                'create_time' => $value->create_time,
                'teacher' => isset($value->teacher->name)?$value->teacher->name:'<span style="color:red;">未分配</span>',
            ];

            $gradeList[] = $data;
        }
        $this->assign('gradeList', $gradeList);
        $this->assign('count', $count);
        return $this->fetch('grade_list');
    }
}

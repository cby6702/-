<?php
/**
 *Created by PhpStorm,
 *User: wangjingxu
 *Date:2017/12/3
 *Time:22:51
 */
namespace app\index\controller;
use app\index\model\Title as TitleModel;
use app\index\model\Grade as GradeModel;
use app\index\model\User as UserModel;
use app\index\model\Student as StudentModel;
use think\migration\command\migrate\Status;
use think\Request;
use think\Session;
use think\Db;
class Title extends Base
{
    //教师列表界面
    public function titleList()
    {
        $userRole=null;
        $userName=null;
        $title=null;
        $count=null;
        $data=null;
        $titleList=null;
        $userRole = Session::get('user_info.role');
        $userName =Session::get('user_info.name');
        if ($userRole == 3) {
            $title= TitleModel::all(['sname'=>$userName]);
        } else {
            $title = TitleModel::all();
        }

        $count = TItleModel::count();

        foreach ($title as $value) {
            $data = [
                'id'=>$value->id,
                'literview'=>$value->literview,
                'begin'=>$value->begin,
                'trans'=>$value->trans,
                'mid'=>$value->mid,
                'paper'=>$value->paper,
                'remark'=>$value->remark,
                'tremark'=>$value->tremark,
                'plea'=>$value->plea,
                'status1' => $value->status1,
                'status2' => $value->status2,
                'status3' => $value->status3,
                'status4' => $value->status4,
                'status5' => $value->status5,
                'status6' => $value->status6,
                'status7' => $value->status7,
                'status8' => $value->status8,
                'status9' => $value->status9,
                'grade' => isset($value->grade->name)?$value->grade->name:'<span style="color:red;">未分配</span>',
                'sname' => $value->sname,
                'tname' => $value->tname,
            ];

            $titleList[] = $data;
        }

        $this -> view -> assign('titleList', $titleList);
        $this -> view -> assign('count', $count);

        $this->assign('title', '教师列表');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');

        return $this->fetch('title_list');
    }

    //添加教师
    public function titleAdd()
    {
        $this->assign('title', '添加教师');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');

        $grade = GradeModel::all(['status'=>1]);

        $this->assign('gradeList', $grade);

        return $this->fetch('title_add');
    }

    //执行添加教师功能
    public function doAdd(Request $request)
    {
        $data = $request->param();
        $status = 0;
        $message = '添加失败';

        $rule = [
            'status1' => "require",
            'sname' => "require",
            'tname' =>"require",
        ];

        $result = $this->validate($data, $rule);

        if ($result === true) {
            $title = TitleModel::create($data);
            if ($title == true) {
                $status = 1;
                $message = '添加成功';
            }
        }

        return ['status'=>$status,'message'=>$message];
    }

    //课程状态切换
    public function setStatus(Request $request)
    {
        $title_id = $request->param('id');
        /*$title_sname=$request->param('sname');*/
        $result = TitleModel::get($title_id);
        if ($result->getData('status1') == 1) {
            TitleModel::update(['status1'=>0],['id'=>$title_id]);
        }
        if ($result->getData('status1') == 0)
        {
            TitleModel::update(['status1'=>1],['id'=>$title_id]);
        }
    }
    public function setStatus2(Request $request)
    {
        $title_id = $request->param('id');
        /*$title_sname=$request->param('sname');*/
        $result = TitleModel::get($title_id);
        if ($result->getData('status2') == 1) {
            TitleModel::update(['status2'=>0],['id'=>$title_id]);
        }
        if ($result->getData('status2') == 0)
        {
            TitleModel::update(['status2'=>1],['id'=>$title_id]);
        }
    }
    public function setStatus5(Request $request)
    {
        $title_id = $request->param('id');
        $result = TitleModel::get($title_id);
        if ($result->getData('status5') == 1) {
            TitleModel::update(['status5'=>0],['id'=>$title_id]);
        } else {
            TitleModel::update(['status5'=>1],['id'=>$title_id]);
        }
    }
    public function setStatus8(Request $request)
    {
        $title_id = $request->param('id');
        $result = TitleModel::get($title_id);
        if ($result->getData('status8') == 1) {
            TitleModel::update(['status8'=>0],['id'=>$title_id]);
        } else {
            TitleModel::update(['status8'=>1],['id'=>$title_id]);
        }
    }
    //教师编辑界面
    public function titleEdit(Request $request)
    {
        $title_id = $request->param('id');
        $result = TitleModel::get($title_id);
        $grade = GradeModel::all(['status'=>1]);

        $this->assign('title', '编辑班级信息');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');
        $this->assign('title_info',$result);
        $this->assign('gradeList', $grade);

        return $this->fetch('title_edit');
    }

    //教师编辑功能
    public function doEdit(Request $request)
    {
        $data = $request->param();
        $condition = ['id'=>$data['id']];

        $result = TitleModel::update($data, $condition);

        if (true == $result) {
            return ['status'=>1, 'message'=>'更新成功'];
        } else {
            return ['status'=>0, 'message'=>'更新失败,请检查'];
        }
    }

    //删除班级
    public function deleteTitle(Request $request)
    {
        $title_id = $request->param('id');
        TitleModel::update(['is_delete'=>1],['id'=>$title_id]);
        TitleModel::destroy($title_id);
    }

    //恢复删除
    public function unDelete()
    {
        TitleModel::update(['delete_time'=>null],['is_delete'=>1]);
    }

    public function upLoad()
    {
        $message = '添加失败';
        $userName =Session::get('user_info.name');
        $title_id = Db::table('title')->where('sname',$userName)->value('id');
       /* $title= TitleModel::all(['sname'=>$userName]);*/

// 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('image');
        if($file){

            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads','',true,false);

            if($info)
            {
                $message = '添加成功';
                TitleModel::update(['id'=>$title_id,'literview'=>$info->getFilename()]);
                TitleModel::update(['id'=>$title_id,'status3'=>1]);
                /*TitleModel::update(['sname'=>$userName,'literview'=>$info->getFilename()]);
                TitleModel::update(['sname'=>$userName,'status3'=>1]);*/
               echo $message;
            }
            else
                {
// 上传失败获取错误信息
                echo $file->getError();
            }
        }
    }

    public function upLoad1()
    {
        $message = '添加失败';
        $userName =Session::get('user_info.name');
        $title_id = Db::table('title')->where('sname',$userName)->value('id');
// 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('image');
        if($file){

            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads','',true,false);

            if($info)
            {
                $message = '添加成功';
                TitleModel::update(['id'=>$title_id,'begin'=>$info->getFilename()]);
                TitleModel::update(['id'=>$title_id,'status4'=>1]);
                echo $message;
            }
            else
            {
// 上传失败获取错误信息
                echo $file->getError();
            }
        }
    }
    public function upLoad2()
    {
        $message = '添加失败';
        $userName =Session::get('user_info.name');
        $title_id = Db::table('title')->where('sname',$userName)->value('id');
// 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('image');
        if($file){

            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads','',true,false);

            if($info)
            {
                $message = '添加成功';
                TitleModel::update(['id'=>$title_id,'trans'=>$info->getFilename()]);
                TitleModel::update(['id'=>$title_id,'status6'=>1]);
                echo $message;
            }
            else
            {
// 上传失败获取错误信息
                echo $file->getError();
            }
        }
    }
    public function upLoad3()
    {
        $message = '添加失败';
        $userName =Session::get('user_info.name');
        $title_id = Db::table('title')->where('sname',$userName)->value('id');
// 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('image');
        if($file){

            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads','',true,false);

            if($info)
            {
                $message = '添加成功';
                TitleModel::update(['id'=>$title_id,'mid'=>$info->getFilename()]);
                TitleModel::update(['id'=>$title_id,'status7'=>1]);
                echo $message;
            }
            else
            {
// 上传失败获取错误信息
                echo $file->getError();
            }
        }
    }
    public function upLoad4()
    {
        $message = '添加失败';
        $userName =Session::get('user_info.name');
        $title_id = Db::table('title')->where('sname',$userName)->value('id');
// 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('image');
        if($file){

            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads','',true,false);

            if($info)
            {
                $message = '添加成功';
                TitleModel::update(['id'=>$title_id,'paper'=>$info->getFilename()]);
                TitleModel::update(['id'=>$title_id,'status9'=>1]);
                echo $message;
            }
            else
            {
// 上传失败获取错误信息
                echo $file->getError();
            }
        }
    }
    public  function search()
    {
        $this->assign('title', '查找论文');
        $this->assign('keywords', '教学管理系统');
        $this->assign('dsc', '教学案例');
        $search = $_POST["username"];
        $titleList = TitleModel::all(['sname'=>$search]);
        $count = TitleModel::count();
        foreach ($titleList as $value) {
            $value->grade = $value->grade->name;
        }
        $this -> view -> assign('titleList', $titleList);
        $this -> view -> assign('count', $count);

        return $this->fetch('title_list');
    }
}

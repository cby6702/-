<?php
/**
 *Created by PhpStorm,
 *User: wangjingxu
 *Date:2017/12/2
 *Time:10:35
 */
namespace app\index\model;
use think\Model;
use traits\model\SoftDelete;

class Title extends Model
{
    //引用软删除方法集
    use SoftDelete;

    //设置当前表默认日期时间显示格式
    protected $dateFormat = 'Y/m/d';

    //定义表中的删除时间字段,来记录删除时间
    protected $deleteTime = 'delete_time';

    // 开启自动写入时间戳
    protected $autoWriteTimestamp = true;

    protected $createTime = 'create_time';

    protected $updateTime = 'update_time';


    // 定义自动完成的属性
    protected $insert = ['status1' => 0,'status2' => 0,'status3' => 0,'status4' =>0 ,'status5' => 0,'status6' => 0,'status7' => 0,'status8' => 0,'status9' => 0];

    // 定义关联方法
    public function grade()
    {
        return $this->belongsTo('Grade');
    }

}

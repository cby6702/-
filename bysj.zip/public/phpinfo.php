<php 
echo phpinfo();
?>